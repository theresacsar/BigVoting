/**
 * 
 */
/**
 * 
 * In this package there are many methods for testing the MapReduce Schwartzset Algorithm proposed in the AAAI-17 submission "Winner Determination in Huge-Elections with MapReduce".
 *  
 * @author -----
 *
 */
package TestSuite;

